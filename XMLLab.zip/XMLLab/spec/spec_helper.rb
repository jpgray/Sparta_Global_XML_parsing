require 'nokogiri'
require_relative '../xml_parsing'

RSpec.configure do |config|
  config.formatter = :documentation
end
